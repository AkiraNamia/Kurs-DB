using System.Text;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;
using MaterialSkin.Controls;
using System.Data.Common;
using System.Drawing;
using System.Security.Policy;
using System.Threading;
using System.Diagnostics;
using System.Text.RegularExpressions;

namespace Kurs
{
    public partial class Form1 : MaterialForm
    {
        readonly MaterialSkin.MaterialSkinManager materialSkinManager;
        public Form1()
        {
            InitializeComponent();
            materialSkinManager = MaterialSkin.MaterialSkinManager.Instance;
            materialSkinManager.EnforceBackcolorOnAllComponents = true;
            materialSkinManager.AddFormToManage(this);
            materialSkinManager.Theme = MaterialSkin.MaterialSkinManager.Themes.LIGHT;
            materialSkinManager.ColorScheme = new MaterialSkin.ColorScheme(MaterialSkin.Primary.Indigo500, MaterialSkin.Primary.Indigo700, MaterialSkin.Primary.Indigo100, MaterialSkin.Accent.Pink200, MaterialSkin.TextShade.WHITE);
        }
        string AlphabetRus = "�����Ũ��������������������������";
        string AlphabetEn = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        string diagonalRu6 = ""; //������ � ���������� �������
        string enddiagonalRu6str = ""; //������ � ���������� �������
        string diagonalRu7 = "";
        string enddiagonalRu7str = ""; //������ � ���������� �������
        string diagonalEn6 = "";
        string enddiagonalEn6str = "";
        string diagonalEn7 = "";
        string enddiagonalEn7str = "";
        char[] newDiagonalRu6; //������������ ������
        char[] endDiagonalRu6;
        char[] newDiagonalEn6;
        char[] endDiagonalEn6;
        char[] newDiagonalRu7;
        char[] endDiagonalRu7;
        char[] newDiagonalEn7;
        char[] endDiagonalEn7;
        //string mainIndexesRu6;
        //int mainIndexesRu7=0;
        //int mainIndexesEn6=0;
        //int mainIndexesEn7=0;

        private void Form1_Load(object sender, EventArgs e)
        {
            //label2.Text = "1. ��� ���������� �������� ������ � ��� ������� � ������� ������ '��������� �������'\n";
            //label2.Text += "2. � ���� '������� ���������'  ������� �����, ������� ������ �����������. ���� ������ ����������� ����� �� ���������� ��������, ������� ������ '������� ����'.\n";
            //label2.Text += "3. ������� ������ '�����������'.\n";
            //label2.Text += "4. � ���� '������������� ���������' �������� ��� ������������� �����.\n";

            //label7.Text = "1. ��� ������������� �������� ������ � ��� ������� � ������� ������ '��������� �������'\n";
            //label7.Text += "2. � ���� '������������� ���������'  ������� �����, ������� ������ ������������.\n";
            //label7.Text += "3. ������� ������ '������������'.\n";
            //label7.Text += "4. � ���� '�������������� ���������' �������� ��� �������������� �����.\n";
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void matrixBut_Click(object sender, EventArgs e)
        {
            char[] ru = AlphabetRus.ToCharArray();
            char[] en = AlphabetEn.ToCharArray();
            int n = 0;
            label2.Visible = true;
            label3.Visible = true;
            label6.Visible = true;

            int[] indexDiag = new int[20];
            dataGridView1.TopLeftHeaderCell.Value = "Matrix";
            DataGridViewColumn column;

            try
            {
                if ((checkBox1.Checked == true && checkBox2.Checked == false) && (checkBox4.Checked == true || checkBox3.Checked == true))
                {
                    dataGridView1.RowCount = 6;
                    dataGridView1.ColumnCount = 6;


                    for (int i = 0; i < 6; i++)
                    {
                        for (int j = 0; j < 6; j++)
                        {
                            if (checkBox3.Checked == true)
                            {
                                if (n == ru.Length)
                                {
                                    n = 0;
                                }
                                column = dataGridView1.Columns[i];
                                column.Width = 30;


                                dataGridView1.Rows[i].Cells[j].Value = ru[n];
                                dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.White;

                                diagonalRu6 += ru[n].ToString();
                                n++;


                            }
                            if (checkBox4.Checked == true)
                            {
                                if (n == en.Length)
                                {
                                    n = 0;
                                }
                                column = dataGridView1.Columns[i];
                                column.Width = 30;
                                dataGridView1.Rows[i].Cells[j].Value = en[n];
                                dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.White;

                                diagonalEn6 += en[n].ToString();
                                n++;
                            }
                        }
                    }

                    dataGridView2.RowCount = 6;
                    dataGridView2.ColumnCount = 6;
                    dataGridView3.RowCount = 6;
                    dataGridView3.ColumnCount = 6;
                    newDiagonalRu6 = diagonalRu6.ToCharArray();
                    newDiagonalEn6 = diagonalEn6.ToCharArray();
                    int nn = 0;
                    int one = 0;
                    int two = 0;
                    int three = 0;
                    int four = 0;
                    int five = 0;
                    int six = 0;
                    int seven = 0;
                    int eight = 0;
                    int nine = 0;
                    int ten = 0;

                    for (int i = 0; i < 6; i++)
                    {
                        for (int j = 0; j < 6; j++)
                        {
                            column = dataGridView2.Columns[i];
                            column.Width = 30;
                            column = dataGridView3.Columns[i];
                            column.Width = 30;
                            if (checkBox3.Checked == true)
                            {
                                dataGridView2.Rows[i].Cells[j].Value = newDiagonalRu6[nn];
                                dataGridView3.Rows[i].Cells[j].Value = newDiagonalRu6[nn];
                                dataGridView2.Rows[i].Cells[j].Style.BackColor = Color.White;
                                dataGridView3.Rows[i].Cells[j].Style.BackColor = Color.White;

                                enddiagonalRu6str += newDiagonalRu6[nn].ToString();
                            }

                            if (checkBox4.Checked == true)
                            {
                                dataGridView2.Rows[i].Cells[j].Value = newDiagonalEn6[nn];
                                dataGridView3.Rows[i].Cells[j].Value = newDiagonalEn6[nn];
                                dataGridView2.Rows[i].Cells[j].Style.BackColor = Color.White;
                                dataGridView3.Rows[i].Cells[j].Style.BackColor = Color.White;

                                enddiagonalEn6str += newDiagonalEn6[nn].ToString();

                            }
                            nn = nn + 7;
                            one++;
                            two++;
                            three++;
                            four++;
                            five++;
                            six++;
                            seven++;
                            eight++;
                            nine++;
                            ten++;
                            if (one == 6) { nn = 1; }
                            if (two == 11) { nn = 2; }
                            if (three == 15) { nn = 3; }
                            if (four == 18) { nn = 4; }
                            if (five == 20) { nn = 5; }
                            if (six == 21) { nn = 6; }
                            if (seven == 26) { nn = 12; }
                            if (eight == 30) { nn = 18; }
                            if (nine == 33) { nn = 24; }
                            if (eight == 35) { nn = 30; }
                        }
                    }
                    //for (int l = 0; l < enddiagonalEn6str.Length; l++)
                    //{
                    //    for (int k = enddiagonalEn6str.Length - 1; k >= 0; k--)
                    //    {
                    //        if (enddiagonalEn6str[l] == enddiagonalEn6str[k])
                    //        {
                    //            //MessageBox.Show(l.ToString() + " " + k.ToString());
                    //            if (endDiagonalEn6[l] == endDiagonalEn6[k])
                    //            {
                    //                //MessageBox.Show(l.ToString() + " " + k.ToString());
                    //                indexDiag[n] = l;
                    //                textBox2.Text += indexDiag[n].ToString() + " ";
                    //                n++;
                    //            }
                    //        }
                    //    }

                    //}
                }

                else if ((checkBox2.Checked == true && checkBox1.Checked == false) && (checkBox4.Checked == true || checkBox3.Checked == true))
                {

                    dataGridView1.RowCount = 7;
                    dataGridView1.ColumnCount = 7;

                    for (int i = 0; i < 7; i++)
                    {
                        for (int j = 0; j < 7; j++)
                        {

                            if (checkBox3.Checked == true)
                            {
                                if (n == ru.Length)
                                {
                                    n = 0;
                                }
                                column = dataGridView1.Columns[i];
                                column.Width = 30;
                                dataGridView1.Rows[i].Cells[j].Value = ru[n];
                                dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.White;
                                diagonalRu7 += ru[n].ToString();

                                n++;
                            }
                            if (checkBox4.Checked == true)
                            {
                                if (n == en.Length)
                                {
                                    n = 0;
                                }
                                column = dataGridView1.Columns[i];
                                column.Width = 30;
                                dataGridView1.Rows[i].Cells[j].Value = en[n];
                                dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.White;
                                diagonalEn7 += en[n].ToString();
                                n++;
                            }
                        }
                    }
                    dataGridView2.RowCount = 7;
                    dataGridView2.ColumnCount = 7;
                    dataGridView3.RowCount = 7;
                    dataGridView3.ColumnCount = 7;
                    newDiagonalRu7 = diagonalRu7.ToCharArray();
                    newDiagonalEn7 = diagonalEn7.ToCharArray();
                    int nn = 0;
                    int one = 0;
                    int two = 0;
                    int three = 0;
                    int four = 0;
                    int five = 0;
                    int six = 0;
                    int seven = 0;
                    int eight = 0;
                    int nine = 0;
                    int ten = 0;
                    int eleven = 0;

                    for (int i = 0; i < 7; i++)
                    {
                        for (int j = 0; j < 7; j++)
                        {
                            column = dataGridView2.Columns[i];
                            column.Width = 30;
                            column = dataGridView3.Columns[i];
                            column.Width = 30;
                            if (checkBox3.Checked == true)
                            {
                                dataGridView2.Rows[i].Cells[j].Value = newDiagonalRu7[nn];
                                dataGridView3.Rows[i].Cells[j].Value = newDiagonalRu7[nn];
                                dataGridView2.Rows[i].Cells[j].Style.BackColor = Color.White;
                                dataGridView3.Rows[i].Cells[j].Style.BackColor = Color.White;

                                enddiagonalRu7str += newDiagonalRu7[nn].ToString();

                            }

                            if (checkBox4.Checked == true)
                            {
                                dataGridView2.Rows[i].Cells[j].Value = newDiagonalEn7[nn];
                                dataGridView3.Rows[i].Cells[j].Value = newDiagonalEn7[nn];
                                dataGridView2.Rows[i].Cells[j].Style.BackColor = Color.White;
                                dataGridView3.Rows[i].Cells[j].Style.BackColor = Color.White;

                                enddiagonalEn7str += newDiagonalEn7[nn].ToString();

                            }
                            nn = nn + 8;
                            one++;
                            two++;
                            three++;
                            four++;
                            five++;
                            six++;
                            seven++;
                            eight++;
                            nine++;
                            ten++;
                            eleven++;
                            if (one == 7) { nn = 1; }
                            if (two == 13) { nn = 2; }
                            if (three == 18) { nn = 3; }
                            if (four == 22) { nn = 4; }
                            if (five == 25) { nn = 5; }
                            if (six == 27) { nn = 6; }
                            if (seven == 28) { nn = 7; }
                            if (eight == 34) { nn = 14; }
                            if (nine == 39) { nn = 21; }
                            if (eight == 43) { nn = 28; }
                            if (ten == 46) { nn = 35; }
                            if (eleven == 48) { nn = 42; }
                        }
                    }
                }
                else if (checkBox1.Checked == true && checkBox2.Checked == true)
                {
                    MessageBox.Show("����� ������� ������ ���� ��� �������.");

                }
                else
                {
                    MessageBox.Show("�������� ��� ������� � ����.");
                }
                infoBox.Text = "������������ ������� �������� ���� ���������� �������� ������� ���������, ����� ���� ����� �� ������� ����������� ������ ������� �������� �� ������, � ����� �� �������.";

            }
            catch
            {
                MessageBox.Show("��������� ���� �����.");
                dataGridView1.ClearSelection();
            }


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        //////////////////////////////////////////////SHIFROVATIE////////////////////////////////////////////////////////
        int[] newIndexesForColor;
        private void button1_Click_1(object sender, EventArgs e)
        {
            materialButton1.Show();

            endDiagonalRu6 = enddiagonalRu6str.ToCharArray();
            endDiagonalRu7 = enddiagonalRu7str.ToCharArray();
            endDiagonalEn6 = enddiagonalEn6str.ToCharArray();
            endDiagonalEn7 = enddiagonalEn7str.ToCharArray();

            int c = 0;
            int n = 0;
            string msgS = textBox1.Text.ToUpper();
            msgS = msgS.ToUpper();
            infoBox.Text = "";
            Stopwatch stopwatch = new Stopwatch(); // ������� ������ Stopwatch

            try
            {
                if (checkBox3.Checked == true && checkBox1.Checked == true)
                {
                    if (Regex.IsMatch(textBox1.Text, "[a-zA-Z]")) MessageBox.Show("��������� ���� �����.");
                    else
                    {

                        stopwatch.Start(); // ��������� ������� �������
                        msgS = System.Text.RegularExpressions.Regex.Replace(msgS, @"[\.!,\s:"";�?ABCDEFGHIJKLMNOPQRSTUVWXYZ]", "");
                        msgS = System.Text.RegularExpressions.Regex.Replace(msgS, @"[-]", "");
                        char[] msg = msgS.ToCharArray();//���������
                        int[] indexDiag = new int[msg.Length];//������� �������� ��������
                        int[] newindexDiag = new int[msg.Length];//����� ������� �������� ���������
                        newIndexesForColor = new int[msg.Length];

                        for (int i = 0; i < endDiagonalRu6.Length; i++)
                        {
                            if (n < msg.Length)
                            {
                                if (msg[n] == endDiagonalRu6[i])
                                {
                                    c = c + i;
                                    indexDiag[n] = i;

                                    n++;
                                    i = -1;

                                }
                            }
                        }
                        while (c > AlphabetRus.Length)
                        {
                            c = c - AlphabetRus.Length;//�������� ����
                        }
                        infoBox.Text += "������� �������� ��������� �� ������������ ������� � ��������� ���������." + Environment.NewLine;
                        for (int i = 0; i < msg.Length; i++)
                        {
                            infoBox.Text += indexDiag[i] + " ";
                        }

                        for (int i = 0; i < msg.Length; i++)
                        {
                            newindexDiag[i] = c + indexDiag[i];
                            infoBox.Text += "����� ������ " + i + "-�� ������� = " + c + "+ " + indexDiag[i] + " = " + newindexDiag[i] + Environment.NewLine;

                            while (newindexDiag[i] >= endDiagonalRu6.Length)
                            {
                                infoBox.Text += "�.�. ������ ������ ������� �������, �� �� ���� �������� ����� �������, �.�. ����� ������ = " + newindexDiag[i] + "- " + endDiagonalRu6.Length + " = ";

                                newindexDiag[i] = newindexDiag[i] - endDiagonalRu6.Length;//��������� ����� ������� 
                                infoBox.Text += newindexDiag[i] + Environment.NewLine;

                            }

                        }
                        string shifrMsgStr = "";
                        infoBox.Text += "�.�. ��� ���������� ������� ������� �������� ������ �������, ��������� ������� �����������. ��� ���� ����� ��� ���������� �������, ��������� ������, ����� ������ ���������� �����, ������������ ���� '_', ������� �������� ������ ������������� ������. ���� '*' �������� ������ ������������� ������ ��� �����." + Environment.NewLine;

                        for (int i = 0; i < msg.Length; i++)
                        {
                            shifrMsgStr += endDiagonalRu6[newindexDiag[i]].ToString();
                            infoBox.Text += newindexDiag[i] + "-�� ������� ������������� ������ " + endDiagonalRu6[newindexDiag[i]].ToString() + Environment.NewLine;

                            if (newindexDiag[i] == 29) { shifrMsgStr += "_"; }
                            if (newindexDiag[i] == 25) { shifrMsgStr += "_"; }
                            if (newindexDiag[i] == 11) { shifrMsgStr += "_"; }
                            newIndexesForColor[i] = newindexDiag[i];
                        }
                        shifrMsgStr += endDiagonalRu6[c].ToString();
                        if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalRu6[c] && c == 29) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalRu6[c] && c == 25) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalRu6[c] && c == 11) shifrMsgStr += "*";


                        char[] shifrMSG = shifrMsgStr.ToCharArray();
                        textBox2.Text = shifrMsgStr.ToString();
                        stopwatch.Stop(); // ������������� ������� �������
                        TimeSpan timeSpan = stopwatch.Elapsed; // �������� �����, ����������� �� ����������
                        label5.Text = timeSpan.TotalMilliseconds.ToString() + " �.c."; // ������� ��������� � �������
                    }

                } //��� �������� 6�6
                if (checkBox3.Checked == true && checkBox2.Checked == true)
                {
                    if (Regex.IsMatch(textBox1.Text, "[a-zA-Z]")) MessageBox.Show("��������� ���� �����.");
                    else{
                        stopwatch.Start(); // ��������� ������� �������
                        msgS = System.Text.RegularExpressions.Regex.Replace(msgS, @"[\.!,\s:"";�?ABCDEFGHIJKLMNOPQRSTUVWXYZ]", "");
                        msgS = System.Text.RegularExpressions.Regex.Replace(msgS, @"[-]", "");
                        char[] msg = msgS.ToCharArray();//���������
                        int[] indexDiag = new int[msg.Length];
                        int[] newindexDiag = new int[msg.Length];
                        newIndexesForColor = new int[msg.Length];


                        for (int i = 0; i < endDiagonalRu7.Length; i++)
                        {
                            if (n < msg.Length)
                            {
                                if (msg[n] == endDiagonalRu7[i])
                                {
                                    c = c + i;
                                    indexDiag[n] = i;
                                    n++;
                                    i = -1;

                                }
                            }
                        }
                        while (c > AlphabetRus.Length)
                        {
                            c = c - AlphabetRus.Length;
                        }
                        infoBox.Text += "������� �������� ��������� �� ������������ ������� � ��������� ���������." + Environment.NewLine;
                        for (int i = 0; i < msg.Length; i++)
                        {
                            infoBox.Text += indexDiag[i] + " ";
                        }
                        infoBox.Text += "���� ����� ����� �������� ���������. ���� �� ������ ������ ���������� ��������, �� �� ���� �������� ��� ������. ���� ����� " + c + Environment.NewLine;

                        for (int i = 0; i < msg.Length; i++)
                        {
                            newindexDiag[i] = c + indexDiag[i];
                            infoBox.Text += "����� ������ " + i + "-�� ������� = " + c + "+ " + indexDiag[i] + " = " + newindexDiag[i] + Environment.NewLine;

                            while (newindexDiag[i] >= endDiagonalRu7.Length)
                            {
                                infoBox.Text += "�.�. ������ ������ ������� �������, �� �� ���� �������� ����� �������, �.�. ����� ������ = " + newindexDiag[i] + "- " + endDiagonalRu6.Length + " = ";
                                newindexDiag[i] = newindexDiag[i] - endDiagonalRu7.Length;
                                infoBox.Text += newindexDiag[i] + Environment.NewLine;
                                newIndexesForColor[i] = newindexDiag[i];

                            }
                        }
                        infoBox.Text += "�.�. ��� ���������� ������� ������� �������� ������ �������, ��������� ������� �����������. ��� ���� ����� ��� ���������� �������, ��������� ������, ����� ������ ���������� �����, ������������ ���� '_', ������� �������� ������ ������������� ������. ���� '*' �������� ������ ������������� ������ ��� �����." + Environment.NewLine;

                        string shifrMsgStr = "";

                        for (int i = 0; i < msg.Length; i++)
                        {
                            shifrMsgStr += endDiagonalRu7[newindexDiag[i]].ToString();
                            infoBox.Text += newindexDiag[i] + "-�� ������� ������������� ������ " + endDiagonalRu7[newindexDiag[i]].ToString() + Environment.NewLine;
                            if (newindexDiag[i] == 48) shifrMsgStr += "_";
                            if (newindexDiag[i] == 47) shifrMsgStr += "_";
                            if (newindexDiag[i] == 46) shifrMsgStr += "_";
                            if (newindexDiag[i] == 45) shifrMsgStr += "_";
                            if (newindexDiag[i] == 44) shifrMsgStr += "_";

                            if (newindexDiag[i] == 42) shifrMsgStr += "_";
                            if (newindexDiag[i] == 41) shifrMsgStr += "_";

                            if (newindexDiag[i] == 38) shifrMsgStr += "_";
                            if (newindexDiag[i] == 37) shifrMsgStr += "_";

                            if (newindexDiag[i] == 34) shifrMsgStr += "_";
                            if (newindexDiag[i] == 32) shifrMsgStr += "_";

                            if (newindexDiag[i] == 29) shifrMsgStr += "_";
                            if (newindexDiag[i] == 28) shifrMsgStr += "_";
                            if (newindexDiag[i] == 17) shifrMsgStr += "_";
                            if (newindexDiag[i] == 12) shifrMsgStr += "_";
                            if (newindexDiag[i] == 11) shifrMsgStr += "_";
                            newIndexesForColor[i] = newindexDiag[i];

                        }
                        shifrMsgStr += endDiagonalRu7[c].ToString();
                        if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalRu7[c] && c == 48) shifrMsgStr += "*";
                        if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalRu7[c] && c == 47) shifrMsgStr += "*";
                        if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalRu7[c] && c == 46) shifrMsgStr += "*";
                        if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalRu7[c] && c == 45) shifrMsgStr += "*";
                        if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalRu7[c] && c == 44) shifrMsgStr += "*";
                        if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalRu7[c] && c == 42) shifrMsgStr += "*";
                        if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalRu7[c] && c == 41) shifrMsgStr += "*";
                        if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalRu7[c] && c == 38) shifrMsgStr += "*";
                        if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalRu7[c] && c == 37) shifrMsgStr += "*";
                        if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalRu7[c] && c == 34) shifrMsgStr += "*";
                        if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalRu7[c] && c == 32) shifrMsgStr += "*";
                        if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalRu7[c] && c == 29) shifrMsgStr += "*";
                        if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalRu7[c] && c == 28) shifrMsgStr += "*";
                        if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalRu7[c] && c == 17) shifrMsgStr += "*";
                        if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalRu7[c] && c == 12) shifrMsgStr += "*";
                        if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalRu7[c] && c == 11) shifrMsgStr += "*";

                        char[] shifrMSG = shifrMsgStr.ToCharArray();
                        int count = 0;
                        textBox2.Text = shifrMsgStr.ToString();
                        stopwatch.Stop(); // ������������� ������� �������
                        TimeSpan timeSpan = stopwatch.Elapsed; // �������� �����, ����������� �� ����������
                        label5.Text = timeSpan.TotalMilliseconds.ToString() + " �.c."; // ������� ��������� � �������
                    }

                } //��� �������� 7�7
                if (checkBox4.Checked == true && checkBox1.Checked == true)
                {
                    if (Regex.IsMatch(textBox1.Text, "[�-��-�]")) MessageBox.Show("��������� ���� �����.");
                    else
                    {
                        stopwatch.Start();
                        msgS = System.Text.RegularExpressions.Regex.Replace(msgS, @"[\.!,\s:"";�?�����Ũ��������������������������]", "");
                        msgS = System.Text.RegularExpressions.Regex.Replace(msgS, @"[-]", "");
                        char[] msg = msgS.ToCharArray();//���������
                        int[] indexDiag = new int[msg.Length];
                        int[] newindexDiag = new int[msg.Length];
                        newIndexesForColor = new int[msg.Length];


                        for (int i = 0; i < endDiagonalEn6.Length; i++)
                        {
                            if (n < msg.Length)
                            {
                                if (msg[n] == endDiagonalEn6[i])
                                {
                                    c = c + i;
                                    indexDiag[n] = i;
                                    n++;
                                    i = -1;

                                }
                            }
                        }

                        while (c > AlphabetEn.Length)
                        {
                            c = c - AlphabetEn.Length;
                        }
                        infoBox.Text += "������� �������� ��������� �� ������������ ������� � ��������� ���������." + Environment.NewLine;
                        for (int i = 0; i < msg.Length; i++)
                        {
                            infoBox.Text += indexDiag[i] + " ";
                        }
                        infoBox.Text += "���� ����� ����� �������� ���������. ���� �� ������ ������ ���������� ��������, �� �� ���� �������� ��� ������. ���� ����� " + c + Environment.NewLine;

                        for (int i = 0; i < msg.Length; i++)
                        {
                            newindexDiag[i] = c + indexDiag[i];
                            infoBox.Text += "����� ������ " + i + "-�� ������� = " + c + "+ " + indexDiag[i] + " = " + newindexDiag[i] + Environment.NewLine;

                            while (newindexDiag[i] >= endDiagonalEn6.Length)
                            {
                                infoBox.Text += "�.�. ������ ������ ������� �������, �� �� ���� �������� ����� �������, �.�. ����� ������ = " + newindexDiag[i] + "- " + endDiagonalRu6.Length + " = ";
                                newindexDiag[i] = newindexDiag[i] - endDiagonalEn6.Length;
                                infoBox.Text += newindexDiag[i] + Environment.NewLine;
                            }

                        }

                        string shifrMsgStr = "";
                        infoBox.Text += "�.�. ��� ���������� ������� ������� �������� ������ �������, ��������� ������� �����������. ��� ���� ����� ��� ���������� �������, ��������� ������, ����� ������ ���������� �����, ������������ ���� '_', ������� �������� ������ ������������� ������. ���� '*' �������� ������ ������������� ������ ��� �����." + Environment.NewLine;

                        for (int i = 0; i < msg.Length; i++)
                        {
                            shifrMsgStr += endDiagonalEn6[newindexDiag[i]].ToString();
                            infoBox.Text += newindexDiag[i] + "-�� ������� ������������� ������ " + endDiagonalEn6[newindexDiag[i]].ToString() + Environment.NewLine;
                            if (newindexDiag[i] == 35) shifrMsgStr += "_";
                            if (newindexDiag[i] == 34) shifrMsgStr += "_";
                            if (newindexDiag[i] == 32) shifrMsgStr += "_";
                            if (newindexDiag[i] == 29) shifrMsgStr += "_";
                            if (newindexDiag[i] == 28) shifrMsgStr += "_";
                            if (newindexDiag[i] == 25) shifrMsgStr += "_";
                            if (newindexDiag[i] == 24) shifrMsgStr += "_";
                            if (newindexDiag[i] == 15) shifrMsgStr += "_";
                            if (newindexDiag[i] == 12) shifrMsgStr += "_";
                            if (newindexDiag[i] == 11) shifrMsgStr += "_";
                            newIndexesForColor[i] = newindexDiag[i];

                        }
                        shifrMsgStr += endDiagonalEn6[c].ToString();
                        if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn6[c] && c == 35) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn6[c] && c == 34) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn6[c] && c == 32) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn6[c] && c == 29) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn6[c] && c == 28) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn6[c] && c == 25) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn6[c] && c == 24) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn6[c] && c == 15) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn6[c] && c == 12) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn6[c] && c == 11) shifrMsgStr += "*";


                        char[] shifrMSG = shifrMsgStr.ToCharArray();


                        textBox2.Text = shifrMsgStr.ToString();
                        stopwatch.Stop(); // ������������� ������� �������
                        TimeSpan timeSpan = stopwatch.Elapsed; // �������� �����, ����������� �� ����������
                        label5.Text = timeSpan.TotalMilliseconds.ToString() + " �.c."; // ������� ��������� � �������
                    }

                } //��� ����������� 6�6
                if (checkBox4.Checked == true && checkBox2.Checked == true)
                {
                    if (Regex.IsMatch(textBox1.Text, "[�-��-�]")) MessageBox.Show("��������� ���� �����.");
                    else
                    {
                        stopwatch.Start();
                        msgS = System.Text.RegularExpressions.Regex.Replace(msgS, @"[\.!,\s:"";�?�����Ũ��������������������������]", "");
                        msgS = System.Text.RegularExpressions.Regex.Replace(msgS, @"[-]", "");
                        char[] msg = msgS.ToCharArray();//���������
                        int[] indexDiag = new int[msg.Length];
                        int[] newindexDiag = new int[msg.Length];
                        newIndexesForColor = new int[msg.Length];


                        for (int i = 0; i < endDiagonalEn7.Length; i++)
                        {
                            if (n < msg.Length)
                            {
                                if (msg[n] == endDiagonalEn7[i])
                                {
                                    c = c + i;
                                    indexDiag[n] = i;
                                    n++;
                                    i = -1;

                                }
                            }

                        }

                        while (c > AlphabetEn.Length)
                        {
                            c = c - AlphabetEn.Length;
                        }

                        infoBox.Text += "������� �������� ��������� �� ������������ ������� � ��������� ���������." + Environment.NewLine;
                        for (int i = 0; i < msg.Length; i++)
                        {
                            infoBox.Text += indexDiag[i] + " ";
                        }
                        infoBox.Text += "���� ����� ����� �������� ���������. ���� �� ������ ������ ���������� ��������, �� �� ���� �������� ��� ������. ���� ����� " + c + Environment.NewLine;

                        for (int i = 0; i < msg.Length; i++)
                        {
                            newindexDiag[i] = c + indexDiag[i];
                            infoBox.Text += "����� ������ " + i + "-�� ������� = " + c + "+ " + indexDiag[i] + " = " + newindexDiag[i] + Environment.NewLine;

                            while (newindexDiag[i] > endDiagonalEn7.Length)
                            {
                                newindexDiag[i] = newindexDiag[i] - endDiagonalEn7.Length;
                                infoBox.Text += newindexDiag[i] + Environment.NewLine;
                            }
                        }
                        infoBox.Text += "�.�. ��� ���������� ������� ������� �������� ������ �������, ��������� ������� �����������. ��� ���� ����� ��� ���������� �������, ��������� ������, ����� ������ ���������� �����, ������������ ���� '_', ������� �������� ������ ������������� ������. ���� '*' �������� ������ ������������� ������ ��� �����." + Environment.NewLine;

                        string shifrMsgStr = "";

                        for (int i = 0; i < msg.Length; i++)
                        {
                            shifrMsgStr += endDiagonalEn7[newindexDiag[i]].ToString();
                            infoBox.Text += newindexDiag[i] + "-�� ������� ������������� ������ " + endDiagonalEn7[newindexDiag[i]].ToString() + Environment.NewLine;
                            if (newindexDiag[i] == 48) shifrMsgStr += "_";
                            if (newindexDiag[i] == 47) shifrMsgStr += "_";
                            if (newindexDiag[i] == 46) shifrMsgStr += "_";
                            if (newindexDiag[i] == 45) shifrMsgStr += "_";
                            if (newindexDiag[i] == 44) shifrMsgStr += "_";
                            if (newindexDiag[i] == 43) shifrMsgStr += "_";
                            if (newindexDiag[i] == 42) shifrMsgStr += "_";
                            if (newindexDiag[i] == 41) shifrMsgStr += "_";
                            if (newindexDiag[i] == 40) shifrMsgStr += "_";

                            if (newindexDiag[i] == 39) shifrMsgStr += "_";
                            if (newindexDiag[i] == 38) shifrMsgStr += "_";
                            if (newindexDiag[i] == 37) shifrMsgStr += "_";
                            if (newindexDiag[i] == 36) shifrMsgStr += "_";
                            if (newindexDiag[i] == 35) shifrMsgStr += "_";
                            if (newindexDiag[i] == 34) shifrMsgStr += "_";
                            if (newindexDiag[i] == 32) shifrMsgStr += "_";
                            if (newindexDiag[i] == 31) shifrMsgStr += "_";
                            if (newindexDiag[i] == 29) shifrMsgStr += "_";
                            if (newindexDiag[i] == 28) shifrMsgStr += "_";
                            if (newindexDiag[i] == 27) shifrMsgStr += "_";
                            if (newindexDiag[i] == 21) shifrMsgStr += "_";
                            if (newindexDiag[i] == 17) shifrMsgStr += "_";
                            if (newindexDiag[i] == 16) shifrMsgStr += "_";
                            newIndexesForColor[i] = newindexDiag[i];

                            //textBox2.Text += newindexDiag[i].ToString()+" ";
                        }
                        shifrMsgStr += endDiagonalEn7[c].ToString();
                        if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn7[c] && c == 48) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn7[c] && c == 47) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn7[c] && c == 46) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn7[c] && c == 45) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn7[c] && c == 44) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn7[c] && c == 43) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn7[c] && c == 42) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn7[c] && c == 41) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn7[c] && c == 40) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn7[c] && c == 39) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn7[c] && c == 38) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn7[c] && c == 37) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn7[c] && c == 36) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn7[c] && c == 35) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn7[c] && c == 34) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn7[c] && c == 32) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn7[c] && c == 31) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn7[c] && c == 29) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn7[c] && c == 28) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn7[c] && c == 27) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn7[c] && c == 21) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn7[c] && c == 17) shifrMsgStr += "*";
                        else if (shifrMsgStr[shifrMsgStr.Length - 1] == endDiagonalEn7[c] && c == 16) shifrMsgStr += "*";

                        dataGridView3.RowCount = 7;
                        dataGridView3.ColumnCount = 7;


                        char[] shifrMSG = shifrMsgStr.ToCharArray();

                        textBox2.Text = shifrMsgStr.ToString();
                        stopwatch.Stop(); // ������������� ������� �������
                        TimeSpan timeSpan = stopwatch.Elapsed; // �������� �����, ����������� �� ����������
                        label5.Text = timeSpan.TotalMilliseconds.ToString() + " �.c."; // ������� ��������� � �������
                    }

                } //��� ����������� 7x7
               
            }
            catch
            {
                MessageBox.Show("��������� ���� �����.");
                dataGridView1.ClearSelection();
            }
        }

        //////////////////////////////////////////////DESHIFROVATIE////////////////////////////////////////////////////////
        private void button2_Click_1(object sender, EventArgs e)
        {
          
            materialButton1.Hide();
            endDiagonalRu6 = enddiagonalRu6str.ToCharArray();
            endDiagonalRu7 = enddiagonalRu7str.ToCharArray();
            endDiagonalEn6 = enddiagonalEn6str.ToCharArray();
            endDiagonalEn7 = enddiagonalEn7str.ToCharArray();
            int c = 0;
            int n = 0;
            string msgS = textBox2.Text.ToUpper();
            char[] msg = msgS.ToCharArray();// ������������� ���������
            try
            {
                if (checkBox3.Checked == true && checkBox1.Checked == true)
                {
                    Stopwatch stopwatch = new Stopwatch(); // ������� ������ Stopwatch
                    stopwatch.Start();
                    int ln = 1;
                    for (int i = 0; i < msg.Length - 1; i++)
                    {
                        if (msg[i + 1] == '_') ln++;
                        if (msg[i + 1] == '*') ln++;
                    }
                    int[] indexDiag = new int[msg.Length - ln];//������� �������� ��������
                    int[] newindexDiag = new int[msg.Length - ln];//����� ������� �������� ���������

                    for (int i = 0; i < endDiagonalRu6.Length; i++)
                    {

                        if (msg[msg.Length - 1] == '*')
                        {
                            if (msg[msg.Length - 2] == endDiagonalRu6[i])
                            {
                                if (i == 0)
                                {
                                    c = 29; break;
                                }
                                else if (i == 5)
                                {
                                    c = 11; break;
                                }
                                else if (i == 6)
                                {
                                    c = 25; break;
                                }


                                break;
                            }

                        }
                        if (msg[msg.Length - 1] == endDiagonalRu6[i])
                        {
                            c = i;
                            break;
                        }

                    }
                    infoBox.Text = "��� ������������� ������� ����������� ������� '_' � '*' ��� ����������� ����������� ��������. ����� ��� ������� �������� �������������� ��������� � ����������� �� �������� �� ������������ �������. ��������� �������� ��������� �������� ����. ���� ����� " + c + Environment.NewLine;
                    int b = 0;
                    for (int i = 0; i < endDiagonalRu6.Length; i++)
                    {
                        if (b < indexDiag.Length)
                        {
                            if (msg[n] == endDiagonalRu6[i])
                            {
                                if (msg[n + 1] == '_' && i == 0)
                                {
                                    indexDiag[b] = 29; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 5)
                                {
                                    indexDiag[b] = 11; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 6)
                                {
                                    indexDiag[b] = 25; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else
                                {
                                    indexDiag[b] = i;
                                    b++;
                                    n++;
                                    i = -1;
                                }

                            }
                        }
                    }
                    for (int i = 0; i < newindexDiag.Length; i++)
                    {
                        newindexDiag[i] = indexDiag[i] - c;
                        infoBox.Text += "����� ������ " + i + "-�� ������� = " + indexDiag[i] + " - " + c + " = " + newindexDiag[i] + Environment.NewLine;
                        while (newindexDiag[i] < 0)
                        {
                            infoBox.Text += "�.�. ������ ������ ������� �������, �� � ���� ���������� ����� �������, ����� ������ = " + newindexDiag[i] + " + " + endDiagonalRu6.Length + " = ";
                            newindexDiag[i] = newindexDiag[i] + endDiagonalRu6.Length;//��������� ����� ������� 
                            infoBox.Text += newindexDiag[i] + Environment.NewLine;
                        }
                    }
                    string deshifrMsgStr = "";

                    for (int i = 0; i < newindexDiag.Length; i++)
                    {

                        deshifrMsgStr += endDiagonalRu6[newindexDiag[i]].ToString();
                        infoBox.Text += newindexDiag[i] + "-�� ������� ������������� ������ " + endDiagonalRu6[newindexDiag[i]].ToString() + Environment.NewLine;

                    }
                    char[] deshifrMSG = deshifrMsgStr.ToCharArray();


                    textBox3.Text = deshifrMsgStr.ToString();
                    stopwatch.Stop(); // ������������� ������� �������
                    TimeSpan timeSpan = stopwatch.Elapsed; // �������� �����, ����������� �� ����������
                    label7.Text = timeSpan.TotalMilliseconds.ToString() + " �.c."; // ������� ��������� � �������



                } //��� �������� 6�6
                if (checkBox3.Checked == true && checkBox2.Checked == true)
                {
                    Stopwatch stopwatch = new Stopwatch(); // ������� ������ Stopwatch
                    stopwatch.Start();
                    int ln = 1;
                    for (int i = 0; i < msg.Length - 1; i++)
                    {
                        if (msg[i + 1] == '_') ln++;
                        if (msg[i + 1] == '*') ln++;
                    }
                    int[] indexDiag = new int[msg.Length - ln];//������� �������� ��������
                    int[] newindexDiag = new int[msg.Length - ln];//����� ������� �������� ���������

                    for (int i = 0; i < endDiagonalRu7.Length; i++)
                    {
                        if (msg[msg.Length - 1] == '*')
                        {
                            if (msg[msg.Length - 2] == endDiagonalRu7[i])
                            {
                                if (i == 8)
                                {
                                    c = 48; break;
                                }
                                else if (i == 14)
                                {
                                    c = 47; break;
                                }
                                else if (i == 13)
                                {
                                    c = 46; break;
                                }
                                else if (i == 19)
                                {
                                    c = 45; break;
                                }
                                else if (i == 18)
                                {
                                    c = 44; break;
                                }
                                else if (i == 23)
                                {
                                    c = 42;
                                    break;
                                }
                                else if (i == 22)
                                {
                                    c = 41; break;
                                }
                                else if (i == 26)
                                {
                                    c = 38; break;
                                }
                                else if (i == 25)
                                {
                                    c = 37; break;
                                }
                                else if (i == 33)
                                {
                                    c = 34; break;
                                }
                                else if (i == 27)
                                {
                                    c = 32; break;
                                }
                                else if (i == 6)
                                {
                                    c = 29; break;
                                }
                                else if (i == 5)
                                {
                                    c = 28; break;
                                }
                                else if (i == 7)
                                {
                                    c = 17; break;
                                }
                                else if (i == 1)
                                {
                                    c = 12; break;
                                }
                                else if (i == 0)
                                {
                                    c = 11; break;
                                }

                                break;
                            }

                        }

                        else if (msg[msg.Length - 1] == endDiagonalRu7[i])
                        {
                            c = i;
                            textBox3.Text = c.ToString() + " ";
                            break;
                        }

                    }
                    int b = 0;
                    infoBox.Text = "��� ������������� ������� ����������� ������� '_' � '*' ��� ����������� ����������� ��������. ����� ��� ������� �������� �������������� ��������� � ����������� �� �������� �� ������������ �������. ��������� �������� ��������� �������� ����. ���� ����� " + c + Environment.NewLine;
                    for (int i = 0; i < endDiagonalRu7.Length; i++)
                    {
                        if (b < indexDiag.Length)
                        {
                            if (msg[n] == endDiagonalRu7[i])
                            {
                                if (msg[n + 1] == '_' && i == 8)
                                {
                                    indexDiag[b] = 48; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 14)
                                {
                                    indexDiag[b] = 47; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 13)
                                {
                                    indexDiag[b] = 46; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 19)
                                {
                                    indexDiag[b] = 45; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 18)
                                {
                                    indexDiag[b] = 44; n += 2;
                                    b++;
                                    i = -1;
                                }

                                else if (msg[n + 1] == '_' && i == 23)
                                {
                                    indexDiag[b] = 42; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 22)
                                {
                                    indexDiag[b] = 41; n += 2;
                                    b++;
                                    i = -1;
                                }

                                else if (msg[n + 1] == '_' && i == 26)
                                {
                                    indexDiag[b] = 38; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 25)
                                {
                                    indexDiag[b] = 37; n += 2;
                                    b++;
                                    i = -1;
                                }

                                else if (msg[n + 1] == '_' && i == 33)
                                {
                                    indexDiag[b] = 34; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 27)
                                {
                                    indexDiag[b] = 32; n += 2;
                                    b++;
                                    i = -1;
                                }

                                else if (msg[n + 1] == '_' && i == 6)
                                {
                                    indexDiag[b] = 29; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 5)
                                {
                                    indexDiag[b] = 28; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 7)
                                {
                                    indexDiag[b] = 17;
                                    n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 1)
                                {
                                    indexDiag[b] = 12;
                                    n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 0)
                                {
                                    indexDiag[b] = 11;
                                    n += 2;
                                    b++;
                                    i = -1;
                                }

                                else
                                {
                                    indexDiag[b] = i;
                                    b++;
                                    n++;
                                    i = -1;
                                }

                            }
                        }
                    }
                    for (int i = 0; i < newindexDiag.Length; i++)
                    {
                        newindexDiag[i] = indexDiag[i] - c;
                        infoBox.Text += "����� ������ " + i + "-�� ������� = " + indexDiag[i] + " - " + c + " = " + newindexDiag[i] + Environment.NewLine;

                        while (newindexDiag[i] < 0)
                        {
                            infoBox.Text += "�.�. ������ ������ ������� �������, �� � ���� ���������� ����� �������, ����� ������ = " + newindexDiag[i] + " + " + endDiagonalRu7.Length + " = ";
                            newindexDiag[i] = newindexDiag[i] + endDiagonalRu7.Length;//��������� ����� ������� 
                            infoBox.Text += newindexDiag[i] + Environment.NewLine;
                        }
                    }
                    string deshifrMsgStr = "";

                    for (int i = 0; i < newindexDiag.Length; i++)
                    {
                        deshifrMsgStr += endDiagonalRu7[newindexDiag[i]].ToString();
                        infoBox.Text += newindexDiag[i] + "-�� ������� ������������� ������ " + endDiagonalRu7[newindexDiag[i]].ToString() + Environment.NewLine;

                    }
                    char[] deshifrMSG = deshifrMsgStr.ToCharArray();

                    textBox3.Text = deshifrMsgStr.ToString();


                    TimeSpan timeSpan = stopwatch.Elapsed; // �������� �����, ����������� �� ����������
                    label7.Text = timeSpan.TotalMilliseconds.ToString() + " �.c."; // ������� ��������� � �������


                } //��� �������� 7�7
                if (checkBox4.Checked == true && checkBox1.Checked == true)
                {
                    Stopwatch stopwatch = new Stopwatch(); // ������� ������ Stopwatch
                    stopwatch.Start();
                    int ln = 1;
                    for (int i = 0; i < msg.Length - 1; i++)
                    {
                        if (msg[i + 1] == '_') ln++;
                        if (msg[i + 1] == '*') ln++;
                    }
                    int[] indexDiag = new int[msg.Length - ln];//������� �������� ��������
                    int[] newindexDiag = new int[msg.Length - ln];//����� ������� �������� ���������

                    for (int i = 0; i < endDiagonalEn6.Length; i++)
                    {
                        if (msg[msg.Length - 1] == '*')
                        {
                            if (msg[msg.Length - 2] == endDiagonalEn6[i])
                            {
                                if (i == 18)
                                {
                                    c = 35; break;
                                }
                                else if (i == 20)
                                {
                                    c = 34; break;
                                }
                                else if (i == 21)
                                {
                                    c = 32; break;
                                }
                                else if (i == 1)
                                {
                                    c = 29; break;
                                }
                                else if (i == 0)
                                {
                                    c = 28; break;
                                }
                                else if (i == 7)
                                {
                                    c = 25;
                                    break;
                                }
                                else if (i == 6)
                                {
                                    c = 24; break;
                                }
                                else if (i == 10)
                                {
                                    c = 15; break;
                                }
                                else if (i == 5)
                                {
                                    c = 12; break;
                                }
                                else if (i == 4)
                                {
                                    c = 11; break;
                                }

                                break;
                            }

                        }
                        else if (msg[msg.Length - 1] == endDiagonalEn6[i])
                        {
                            c = i;
                            break;
                        }


                    }
                    int b = 0;
                    infoBox.Text = "��� ������������� ������� ����������� ������� '_' � '*' ��� ����������� ����������� ��������. ����� ��� ������� �������� �������������� ��������� � ����������� �� �������� �� ������������ �������. ��������� �������� ��������� �������� ����. ���� ����� " + c + Environment.NewLine;

                    for (int i = 0; i < endDiagonalEn6.Length; i++)
                    {
                        if (b < indexDiag.Length)
                        {
                            if (msg[n] == endDiagonalEn6[i])
                            {
                                if (msg[n + 1] == '_' && i == 18)
                                {
                                    indexDiag[b] = 35; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 20)
                                {
                                    indexDiag[b] = 34; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 21)
                                {
                                    indexDiag[b] = 32; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 1)
                                {
                                    indexDiag[b] = 29; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 0)
                                {
                                    indexDiag[b] = 28; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 7)
                                {
                                    indexDiag[b] = 25;
                                    n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 6)
                                {
                                    indexDiag[b] = 24; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 10)
                                {
                                    indexDiag[b] = 15; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 5)
                                {
                                    indexDiag[b] = 12; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 4)
                                {
                                    indexDiag[b] = 11; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else
                                {
                                    indexDiag[b] = i;
                                    b++;
                                    n++;
                                    i = -1;
                                }

                            }
                        }
                    }

                    for (int i = 0; i < newindexDiag.Length; i++)
                    {
                        newindexDiag[i] = indexDiag[i] - c;
                        infoBox.Text += "����� ������ " + i + "-�� ������� = " + indexDiag[i] + " - " + c + " = " + newindexDiag[i] + Environment.NewLine;

                        while (newindexDiag[i] < 0)
                        {
                            infoBox.Text += "�.�. ������ ������ ������� �������, �� � ���� ���������� ����� �������, ����� ������ = " + newindexDiag[i] + " + " + endDiagonalEn6.Length + " = ";
                            newindexDiag[i] = newindexDiag[i] + endDiagonalEn6.Length;//��������� ����� ������� 
                            infoBox.Text += newindexDiag[i] + Environment.NewLine;
                        }
                    }
                    string deshifrMsgStr = "";
                    for (int i = 0; i < newindexDiag.Length; i++)
                    {
                        deshifrMsgStr += endDiagonalEn6[newindexDiag[i]].ToString();
                        infoBox.Text += newindexDiag[i] + "-�� ������� ������������� ������ " + endDiagonalEn6[newindexDiag[i]].ToString() + Environment.NewLine;

                    }

                    char[] deshifrMSG = deshifrMsgStr.ToCharArray();
                    textBox3.Text = deshifrMsgStr.ToString();

                    TimeSpan timeSpan = stopwatch.Elapsed; // �������� �����, ����������� �� ����������
                    label7.Text = timeSpan.TotalMilliseconds.ToString() + " �.c."; // ������� ��������� � �������


                } //��� ����������� 6�6
                if (checkBox4.Checked == true && checkBox2.Checked == true)
                {

                    Stopwatch stopwatch = new Stopwatch(); // ������� ������ Stopwatch
                    stopwatch.Start();
                    int ln = 1;
                    for (int i = 0; i < msg.Length - 1; i++)
                    {
                        if (msg[i + 1] == '_' || msg[i + 1] == '*') ln++;
                    }
                    int[] indexDiag = new int[msg.Length - ln];//������� �������� ��������
                    int[] newindexDiag = new int[msg.Length - ln];//����� ������� �������� ���������

                    for (int i = 0; i < endDiagonalEn7.Length; i++)
                    {
                        if (msg[msg.Length - 1] == '*')
                        {
                            if (msg[msg.Length - 2] == endDiagonalEn7[i])
                            {
                                if (i == 2)
                                {
                                    c = 48; break;
                                }
                                else if (i == 9)
                                {
                                    c = 47; break;
                                }
                                else if (i == 8)
                                {
                                    c = 46; break;
                                }
                                else if (i == 15)
                                {
                                    c = 45; break;
                                }
                                else if (i == 14)
                                {
                                    c = 44; break;
                                }
                                else if (i == 13)
                                {
                                    c = 43;
                                    break;
                                }
                                else if (i == 20)
                                {
                                    c = 42; break;
                                }
                                else if (i == 19)
                                {
                                    c = 41; break;
                                }
                                else if (i == 18)
                                {
                                    c = 40; break;
                                }
                                else if (i == 33)
                                {
                                    c = 39; break;
                                }
                                else if (i == 24)
                                {
                                    c = 38; break;
                                }
                                else if (i == 23)
                                {
                                    c = 37; break;
                                }
                                else if (i == 22)
                                {
                                    c = 36; break;
                                }
                                else if (i == 6)
                                {
                                    c = 35; break;
                                }
                                else if (i == 5)
                                {
                                    c = 34; break;
                                }
                                else if (i == 26)
                                {
                                    c = 32; break;
                                }
                                else if (i == 25)
                                {
                                    c = 31;
                                    break;
                                }
                                else if (i == 12)
                                {
                                    c = 29; break;
                                }
                                else if (i == 11)
                                {
                                    c = 28; break;
                                }
                                else if (i == 4)
                                {
                                    c = 27;
                                    break;
                                }
                                else if (i == 7)
                                {
                                    c = 21;
                                    break;
                                }
                                else if (i == 1)
                                {
                                    c = 17;
                                    break;
                                }
                                else if (i == 0)
                                {
                                    c = 16;
                                    break;
                                }

                                break;
                            }

                        }
                        if (msg[msg.Length - 1] == endDiagonalEn7[i])
                        {
                            c = i;
                            break;
                        }
                    }

                    int b = 0;
                    infoBox.Text = "��� ������������� ������� ����������� ������� '_' � '*' ��� ����������� ����������� ��������. ����� ��� ������� �������� �������������� ��������� � ����������� �� �������� �� ������������ �������. ��������� �������� ��������� �������� ����. ���� ����� " + c + Environment.NewLine;

                    for (int i = 0; i < endDiagonalEn7.Length; i++)
                    {
                        if (b < indexDiag.Length)
                        {
                            if (msg[n] == endDiagonalEn7[i])
                            {
                                if (msg[n + 1] == '_' && i == 2)
                                {
                                    indexDiag[b] = 48; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 9)
                                {
                                    indexDiag[b] = 47; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 8)
                                {
                                    indexDiag[b] = 46; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 15)
                                {
                                    indexDiag[b] = 45; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 14)
                                {
                                    indexDiag[b] = 44; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 13)
                                {
                                    indexDiag[b] = 43;
                                    n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 20)
                                {
                                    indexDiag[b] = 42; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 19)
                                {
                                    indexDiag[b] = 41; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 18)
                                {
                                    indexDiag[b] = 40; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 33)
                                {
                                    indexDiag[b] = 39; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 24)
                                {
                                    indexDiag[b] = 38; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 23)
                                {
                                    indexDiag[b] = 37; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 22)
                                {
                                    indexDiag[b] = 36; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 6)
                                {
                                    indexDiag[b] = 35; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 5)
                                {
                                    indexDiag[b] = 34; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 26)
                                {
                                    indexDiag[b] = 32; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 25)
                                {
                                    indexDiag[b] = 31;
                                    n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 12)
                                {
                                    indexDiag[b] = 29; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 11)
                                {
                                    indexDiag[b] = 28; n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 4)
                                {
                                    indexDiag[b] = 27;
                                    n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 7)
                                {
                                    indexDiag[b] = 21;
                                    n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 1)
                                {
                                    indexDiag[b] = 17;
                                    n += 2;
                                    b++;
                                    i = -1;
                                }
                                else if (msg[n + 1] == '_' && i == 0)
                                {
                                    indexDiag[b] = 16;
                                    n += 2;
                                    b++;
                                    i = -1;
                                }
                                else
                                {
                                    indexDiag[b] = i;
                                    b++;
                                    n++;
                                    i = -1;
                                }

                            }
                        }
                    }


                    for (int k = 0; k < newindexDiag.Length; k++)
                    {
                        newindexDiag[k] = indexDiag[k] - c;
                        infoBox.Text += "����� ������ " + k + "-�� ������� = " + indexDiag[k] + " - " + c + " = " + newindexDiag[k] + Environment.NewLine;

                        while (newindexDiag[k] < 0)
                        {
                            infoBox.Text += "�.�. ������ ������ ������� �������, �� � ���� ���������� ����� �������, ����� ������ = " + newindexDiag[k] + " + " + endDiagonalEn7.Length + " = ";
                            newindexDiag[k] = newindexDiag[k] + endDiagonalEn7.Length;//��������� ����� ������� 
                            infoBox.Text += newindexDiag[k] + Environment.NewLine;
                        }
                    }
                    string deshifrMsgStr = "";
                    for (int i = 0; i < newindexDiag.Length; i++)
                    {
                        deshifrMsgStr += endDiagonalEn7[newindexDiag[i]].ToString();
                        infoBox.Text += newindexDiag[i] + "-�� ������� ������������� ������ " + endDiagonalEn7[newindexDiag[i]].ToString() + Environment.NewLine;

                    }

                    char[] deshifrMSG = deshifrMsgStr.ToCharArray();


                    textBox3.Text = deshifrMsgStr.ToString();
                    TimeSpan timeSpan = stopwatch.Elapsed; // �������� �����, ����������� �� ����������
                    label7.Text = timeSpan.TotalMilliseconds.ToString() + " �.c."; // ������� ��������� � �������

                } //��� ����������� 7x7
            }
            catch
            {
                MessageBox.Show("��������� ���� �����.");
                dataGridView1.ClearSelection();
            }
        }

        private void FileBut_Click(object sender, EventArgs e)
        {
            try
            {
                if (checkBox3.Checked == true)
                {
                    OpenFileDialog text = new OpenFileDialog();
                    text.Filter = "Blablabla |*.txt";
                    if (text.ShowDialog() == DialogResult.OK)
                    {
                        string f_text = File.ReadAllText(text.FileName, Encoding.Default);
                        f_text = f_text.ToUpper();
                        f_text = System.Text.RegularExpressions.Regex.Replace(f_text, @"[\'.!,\s:"";�?ABCDEFGHIJKLMNOPQRSTUVWXYZ]", "");
                        f_text = System.Text.RegularExpressions.Regex.Replace(f_text, @"[-]", "");

                        textBox1.Text = f_text;
                    }
                }
                else if (checkBox4.Checked == true)
                {
                    OpenFileDialog text = new OpenFileDialog();
                    text.Filter = "Blablabla |*.txt";
                    if (text.ShowDialog() == DialogResult.OK)
                    {
                        string f_text = File.ReadAllText(text.FileName, Encoding.Default);
                        f_text = f_text.ToUpper();
                        f_text = System.Text.RegularExpressions.Regex.Replace(f_text, @"[\'.!,\s:"";�?�����Ũ��������������������������]", "");
                        f_text = System.Text.RegularExpressions.Regex.Replace(f_text, @"[-]", "");

                        textBox1.Text = f_text;
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }



        private void label6_Click(object sender, EventArgs e)
        {

        }

      

        private void button3_Click_1(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog text = new OpenFileDialog();
                if (text.ShowDialog() == DialogResult.OK)
                {
                    string lines = textBox2.Text;
                    System.IO.File.WriteAllText(text.FileName, lines);
                    //f_text = f_text.ToUpper();
                    //f_text = System.Text.RegularExpressions.Regex.Replace(f_text, @"[\.!,\s:"";�?ABCDEFGHIJKLMNOPQRSTUVWXYZ]", "");
                    //f_text = System.Text.RegularExpressions.Regex.Replace(f_text, @"[-]", "");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR!!!");
            }
        }
        private void button4_Click_1(object sender, EventArgs e)
        {
            int n = 0;
            dataGridView1.TopLeftHeaderCell.Value = "Matrix";
            DataGridViewColumn column;
            DataGridViewColumn column2;

            try
            {
                if ((checkBox1.Checked == true && checkBox2.Checked == false) && (checkBox4.Checked == true || checkBox3.Checked == true))
                {
                    dataGridView1.RowCount = 6;
                    dataGridView1.ColumnCount = 6;
                    dataGridView3.RowCount = 6;
                    dataGridView3.ColumnCount = 6;


                    for (int i = 0; i < 6; i++)
                    {
                        for (int j = 0; j < 6; j++)
                        {
                            column = dataGridView1.Columns[i];
                            column.Width = 30;
                            dataGridView1.Rows[i].Cells[j].Value = n;
                            dataGridView3.Rows[i].Cells[j].Value = n;
                            n++;

                        }
                    }
                    for (int i = 0; i < 6; i++)
                    {
                        for (int j = 0; j < 6; j++)
                        {
                            if (i == j) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.BlueViolet;
                            if (i == j - 1) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.AliceBlue;
                            if (i == j - 2) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.CadetBlue;
                            if (i == j - 3) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.CornflowerBlue;
                            if (i == j - 4) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.DarkBlue;
                            if (i == j - 5) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.DarkSlateBlue;
                            if (i == j + 1) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.AliceBlue;
                            if (i == j + 2) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.CadetBlue;
                            if (i == j + 3) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.CornflowerBlue;
                            if (i == j + 4) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.DarkBlue;
                            if (i == j + 5) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.DarkSlateBlue;


                        }
                    }

                    dataGridView2.RowCount = 6;
                    dataGridView2.ColumnCount = 6;
                    int nn = 0;
                    int one = 0;
                    int two = 0;
                    int three = 0;
                    int four = 0;
                    int five = 0;
                    int six = 0;
                    int seven = 0;
                    int eight = 0;
                    int nine = 0;
                    int ten = 0;


                    for (int j = 0; j < 6; j++)
                    {
                        dataGridView2.Rows[0].Cells[j].Style.BackColor = Color.BlueViolet;

                    }

                    for (int j = 0; j < 5; j++)
                    {
                        dataGridView2.Rows[1].Cells[j].Style.BackColor = Color.AliceBlue;

                    }
                    for (int j = 0; j < 6; j++)
                    {
                        dataGridView2.Rows[2].Cells[j].Style.BackColor = Color.CadetBlue;
                        if (j >= 3) dataGridView2.Rows[2].Cells[j].Style.BackColor = Color.CornflowerBlue;

                    }

                    for (int j = 0; j < 6; j++)
                    {
                        dataGridView2.Rows[3].Cells[j].Style.BackColor = Color.DarkBlue;
                        if (j == 2) dataGridView2.Rows[3].Cells[j].Style.BackColor = Color.DarkSlateBlue;
                        if (j > 2) dataGridView2.Rows[3].Cells[j].Style.BackColor = Color.AliceBlue;

                    }
                    dataGridView2.Rows[1].Cells[5].Style.BackColor = Color.CadetBlue;
                    for (int j = 0; j < 6; j++)
                    {
                        dataGridView2.Rows[4].Cells[j].Style.BackColor = Color.AliceBlue;
                        if (j >= 2) dataGridView2.Rows[4].Cells[j].Style.BackColor = Color.CadetBlue;

                    }
                    for (int j = 0; j < 6; j++)
                    {
                        dataGridView2.Rows[5].Cells[j].Style.BackColor = Color.CornflowerBlue;
                        if (j > 2) dataGridView2.Rows[5].Cells[j].Style.BackColor = Color.DarkBlue;
                        if (j == 5) dataGridView2.Rows[5].Cells[j].Style.BackColor = Color.DarkSlateBlue;

                    }



                    for (int i = 0; i < 6; i++)
                    {
                        for (int j = 0; j < 6; j++)
                        {
                            column = dataGridView2.Columns[i];
                            column2 = dataGridView3.Columns[i];
                            column.Width = 30;
                            column2.Width = 30;
                            dataGridView2.Rows[i].Cells[j].Value = nn;
                            nn = nn + 7;
                            one++;
                            two++;
                            three++;
                            four++;
                            five++;
                            six++;
                            seven++;
                            eight++;
                            nine++;
                            ten++;
                            if (one == 6)
                            {
                                nn = 1;
                            }
                            if (two == 11)
                            {
                                nn = 2;
                            }
                            if (three == 15)
                            {
                                nn = 3;
                            }
                            if (four == 18) { nn = 4; }
                            if (five == 20) { nn = 5; }
                            if (six == 21) { nn = 6; }
                            if (seven == 26) { nn = 12; }
                            if (eight == 30) { nn = 18; }
                            if (nine == 33) { nn = 24; }
                            if (eight == 35) { nn = 30; }
                        }
                    }

                }


                else if ((checkBox2.Checked == true && checkBox1.Checked == false) && (checkBox4.Checked == true || checkBox3.Checked == true))
                {

                    dataGridView1.RowCount = 7;
                    dataGridView1.ColumnCount = 7;
                    dataGridView3.RowCount = 7;
                    dataGridView3.ColumnCount = 7;
                    for (int i = 0; i < 7; i++)
                    {
                        for (int j = 0; j < 7; j++)
                        {



                            column = dataGridView1.Columns[i];
                            column2 = dataGridView3.Columns[i];
                            column.Width = 30;
                            column2.Width = 30;
                            dataGridView1.Rows[i].Cells[j].Value = n;
                            dataGridView3.Rows[i].Cells[j].Value = n;
                            n++;

                        }
                    }
                    for (int i = 0; i < 7; i++)
                    {
                        for (int j = 0; j < 7; j++)
                        {
                            if (i == j) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.BlueViolet;
                            if (i == j - 1) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.AliceBlue;
                            if (i == j - 2) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.CadetBlue;
                            if (i == j - 3) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.CornflowerBlue;
                            if (i == j - 4) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.DarkBlue;
                            if (i == j - 5) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.DarkSlateBlue;
                            if (i == j - 6) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.DeepSkyBlue;
                            if (i == j + 1) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.AliceBlue;
                            if (i == j + 2) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.CadetBlue;
                            if (i == j + 3) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.CornflowerBlue;
                            if (i == j + 4) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.DarkBlue;
                            if (i == j + 5) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.DarkSlateBlue;
                            if (i == j + 6) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.DeepSkyBlue;


                        }
                    }
                    dataGridView2.RowCount = 7;
                    dataGridView2.ColumnCount = 7;
                    int nn = 0;
                    int one = 0;
                    int two = 0;
                    int three = 0;
                    int four = 0;
                    int five = 0;
                    int six = 0;
                    int seven = 0;
                    int eight = 0;
                    int nine = 0;
                    int ten = 0;
                    int eleven = 0;
                    for (int j = 0; j < 7; j++)
                    {
                        dataGridView2.Rows[0].Cells[j].Style.BackColor = Color.BlueViolet;

                    }

                    for (int j = 0; j < 7; j++)
                    {
                        dataGridView2.Rows[1].Cells[j].Style.BackColor = Color.AliceBlue;
                        if (j == 6) dataGridView2.Rows[1].Cells[j].Style.BackColor = Color.CadetBlue;


                    }

                    for (int j = 0; j < 7; j++)
                    {
                        dataGridView2.Rows[2].Cells[j].Style.BackColor = Color.CadetBlue;
                        if (j >= 4) dataGridView2.Rows[2].Cells[j].Style.BackColor = Color.CornflowerBlue;

                    }
                    dataGridView2.Rows[3].Cells[0].Style.BackColor = Color.CornflowerBlue;

                    for (int j = 1; j < 7; j++)
                    {

                        dataGridView2.Rows[3].Cells[j].Style.BackColor = Color.DarkBlue;
                        if (j >= 4) dataGridView2.Rows[3].Cells[j].Style.BackColor = Color.DarkSlateBlue;
                        if (j == 6) dataGridView2.Rows[3].Cells[j].Style.BackColor = Color.DeepSkyBlue;

                    }

                    for (int j = 0; j < 7; j++)
                    {
                        dataGridView2.Rows[4].Cells[j].Style.BackColor = Color.AliceBlue;
                        if (j == 6) dataGridView2.Rows[4].Cells[j].Style.BackColor = Color.CadetBlue;


                    }

                    for (int j = 0; j < 7; j++)
                    {
                        dataGridView2.Rows[5].Cells[j].Style.BackColor = Color.CadetBlue;
                        if (j >= 4) dataGridView2.Rows[5].Cells[j].Style.BackColor = Color.CornflowerBlue;

                    }
                    dataGridView2.Rows[6].Cells[0].Style.BackColor = Color.CornflowerBlue;

                    for (int j = 1; j < 7; j++)
                    {

                        dataGridView2.Rows[6].Cells[j].Style.BackColor = Color.DarkBlue;
                        if (j >= 4) dataGridView2.Rows[6].Cells[j].Style.BackColor = Color.DarkSlateBlue;
                        if (j == 6) dataGridView2.Rows[6].Cells[j].Style.BackColor = Color.DeepSkyBlue;

                    }

                    for (int i = 0; i < 7; i++)
                    {
                        for (int j = 0; j < 7; j++)
                        {
                            column = dataGridView2.Columns[i];
                            column.Width = 30;


                            dataGridView2.Rows[i].Cells[j].Value = nn;


                            nn = nn + 8;
                            one++;
                            two++;
                            three++;
                            four++;
                            five++;
                            six++;
                            seven++;
                            eight++;
                            nine++;
                            ten++;
                            eleven++;
                            if (one == 7) { nn = 1; }
                            if (two == 13) { nn = 2; }
                            if (three == 18) { nn = 3; }
                            if (four == 22) { nn = 4; }
                            if (five == 25) { nn = 5; }
                            if (six == 27) { nn = 6; }
                            if (seven == 28) { nn = 7; }
                            if (eight == 34) { nn = 14; }
                            if (nine == 39) { nn = 21; }
                            if (eight == 43) { nn = 28; }
                            if (ten == 46) { nn = 35; }
                            if (eleven == 48) { nn = 42; }
                        }
                    }
                }
                else if (checkBox1.Checked == true && checkBox2.Checked == true)
                {
                    MessageBox.Show("����� ������� ������ ���� ��� �������.");

                }
                else
                {
                    MessageBox.Show("�������� ��� ������� � ����.");
                }

            }
            catch
            {
                MessageBox.Show("��������� ���� �����.");
                dataGridView1.ClearSelection();
            }

        }


        private void button5_Click(object sender, EventArgs e)
        {
            char[] ru = AlphabetRus.ToCharArray();
            char[] en = AlphabetEn.ToCharArray();
            int n = 0;
            dataGridView3.RowCount = 7;
            dataGridView3.ColumnCount = 7;
            int[] indexDiag = new int[20];
            dataGridView1.TopLeftHeaderCell.Value = "Matrix";
            DataGridViewColumn column;

            try
            {
                if ((checkBox1.Checked == true && checkBox2.Checked == false) && (checkBox4.Checked == true || checkBox3.Checked == true))
                {
                    dataGridView1.RowCount = 6;
                    dataGridView1.ColumnCount = 6;


                    for (int i = 0; i < 6; i++)
                    {
                        for (int j = 0; j < 6; j++)
                        {
                            if (checkBox3.Checked == true)
                            {
                                if (n == ru.Length)
                                {
                                    n = 0;
                                }
                                column = dataGridView1.Columns[i];
                                column.Width = 30;
                                dataGridView1.Rows[i].Cells[j].Value = ru[n];
                                dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.White;
                                diagonalRu6 += ru[n].ToString();
                                n++;


                            }
                            if (checkBox4.Checked == true)
                            {
                                if (n == en.Length)
                                {
                                    n = 0;
                                }
                                column = dataGridView1.Columns[i];
                                column.Width = 30;
                                dataGridView1.Rows[i].Cells[j].Value = en[n];
                                dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.White;

                                diagonalEn6 += en[n].ToString();
                                n++;
                            }
                        }
                    }

                    dataGridView2.RowCount = 6;
                    dataGridView2.ColumnCount = 6;
                    dataGridView3.RowCount = 6;
                    dataGridView3.ColumnCount = 6;
                    newDiagonalRu6 = diagonalRu6.ToCharArray();
                    newDiagonalEn6 = diagonalEn6.ToCharArray();
                    int nn = 0;
                    int one = 0;
                    int two = 0;
                    int three = 0;
                    int four = 0;
                    int five = 0;
                    int six = 0;
                    int seven = 0;
                    int eight = 0;
                    int nine = 0;
                    int ten = 0;

                    for (int i = 0; i < 6; i++)
                    {
                        for (int j = 0; j < 6; j++)
                        {
                            column = dataGridView2.Columns[i];
                            column.Width = 30;
                            if (checkBox3.Checked == true)
                            {
                                dataGridView2.Rows[i].Cells[j].Value = newDiagonalRu6[nn];
                                dataGridView3.Rows[i].Cells[j].Value = newDiagonalRu6[nn];
                                dataGridView2.Rows[i].Cells[j].Style.BackColor = Color.White;
                                dataGridView3.Rows[i].Cells[j].Style.BackColor = Color.White;

                                enddiagonalRu6str += newDiagonalRu6[nn].ToString();
                            }

                            if (checkBox4.Checked == true)
                            {
                                dataGridView2.Rows[i].Cells[j].Value = newDiagonalEn6[nn];
                                dataGridView3.Rows[i].Cells[j].Value = newDiagonalEn6[nn];
                                dataGridView2.Rows[i].Cells[j].Style.BackColor = Color.White;
                                dataGridView3.Rows[i].Cells[j].Style.BackColor = Color.White;

                                enddiagonalEn6str += newDiagonalEn6[nn].ToString();

                            }
                            nn = nn + 7;
                            one++;
                            two++;
                            three++;
                            four++;
                            five++;
                            six++;
                            seven++;
                            eight++;
                            nine++;
                            ten++;
                            if (one == 6) { nn = 1; }
                            if (two == 11) { nn = 2; }
                            if (three == 15) { nn = 3; }
                            if (four == 18) { nn = 4; }
                            if (five == 20) { nn = 5; }
                            if (six == 21) { nn = 6; }
                            if (seven == 26) { nn = 12; }
                            if (eight == 30) { nn = 18; }
                            if (nine == 33) { nn = 24; }
                            if (eight == 35) { nn = 30; }
                        }
                    }
                    //for (int l = 0; l < enddiagonalEn6str.Length; l++)
                    //{
                    //    for (int k = enddiagonalEn6str.Length - 1; k >= 0; k--)
                    //    {
                    //        if (enddiagonalEn6str[l] == enddiagonalEn6str[k])
                    //        {
                    //            //MessageBox.Show(l.ToString() + " " + k.ToString());
                    //            if (endDiagonalEn6[l] == endDiagonalEn6[k])
                    //            {
                    //                //MessageBox.Show(l.ToString() + " " + k.ToString());
                    //                indexDiag[n] = l;
                    //                textBox2.Text += indexDiag[n].ToString() + " ";
                    //                n++;
                    //            }
                    //        }
                    //    }

                    //}
                }

                else if ((checkBox2.Checked == true && checkBox1.Checked == false) && (checkBox4.Checked == true || checkBox3.Checked == true))
                {

                    dataGridView1.RowCount = 7;
                    dataGridView1.ColumnCount = 7;
                    for (int i = 0; i < 7; i++)
                    {
                        for (int j = 0; j < 7; j++)
                        {

                            if (checkBox3.Checked == true)
                            {
                                if (n == ru.Length)
                                {
                                    n = 0;
                                }
                                column = dataGridView1.Columns[i];
                                column.Width = 30;
                                dataGridView1.Rows[i].Cells[j].Value = ru[n];
                                dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.White;

                                diagonalRu7 += ru[n].ToString();

                                n++;
                            }
                            if (checkBox4.Checked == true)
                            {
                                if (n == en.Length)
                                {
                                    n = 0;
                                }
                                column = dataGridView1.Columns[i];
                                column.Width = 30;
                                dataGridView1.Rows[i].Cells[j].Value = en[n];
                                dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.White;

                                diagonalEn7 += en[n].ToString();
                                n++;
                            }
                        }
                    }
                    dataGridView2.RowCount = 7;
                    dataGridView2.ColumnCount = 7;
                    dataGridView3.RowCount = 7;
                    dataGridView3.ColumnCount = 7;
                    newDiagonalRu7 = diagonalRu7.ToCharArray();
                    newDiagonalEn7 = diagonalEn7.ToCharArray();
                    int nn = 0;
                    int one = 0;
                    int two = 0;
                    int three = 0;
                    int four = 0;
                    int five = 0;
                    int six = 0;
                    int seven = 0;
                    int eight = 0;
                    int nine = 0;
                    int ten = 0;
                    int eleven = 0;

                    for (int i = 0; i < 7; i++)
                    {
                        for (int j = 0; j < 7; j++)
                        {
                            column = dataGridView2.Columns[i];
                            column.Width = 30;
                            column = dataGridView3.Columns[i];
                            column.Width = 30;
                            if (checkBox3.Checked == true)
                            {
                                dataGridView2.Rows[i].Cells[j].Value = newDiagonalRu7[nn];
                                dataGridView3.Rows[i].Cells[j].Value = newDiagonalRu7[nn];
                                dataGridView2.Rows[i].Cells[j].Style.BackColor = Color.White;
                                dataGridView3.Rows[i].Cells[j].Style.BackColor = Color.White;

                                enddiagonalRu7str += newDiagonalRu7[nn].ToString();

                            }

                            if (checkBox4.Checked == true)
                            {
                                dataGridView2.Rows[i].Cells[j].Value = newDiagonalEn7[nn];
                                dataGridView3.Rows[i].Cells[j].Value = newDiagonalEn7[nn];
                                dataGridView2.Rows[i].Cells[j].Style.BackColor = Color.White;
                                dataGridView3.Rows[i].Cells[j].Style.BackColor = Color.White;

                                enddiagonalEn7str += newDiagonalEn7[nn].ToString();

                            }
                            nn = nn + 8;
                            one++;
                            two++;
                            three++;
                            four++;
                            five++;
                            six++;
                            seven++;
                            eight++;
                            nine++;
                            ten++;
                            eleven++;
                            if (one == 7) { nn = 1; }
                            if (two == 13) { nn = 2; }
                            if (three == 18) { nn = 3; }
                            if (four == 22) { nn = 4; }
                            if (five == 25) { nn = 5; }
                            if (six == 27) { nn = 6; }
                            if (seven == 28) { nn = 7; }
                            if (eight == 34) { nn = 14; }
                            if (nine == 39) { nn = 21; }
                            if (eight == 43) { nn = 28; }
                            if (ten == 46) { nn = 35; }
                            if (eleven == 48) { nn = 42; }
                        }
                    }
                }
                else if (checkBox1.Checked == true && checkBox2.Checked == true)
                {
                    MessageBox.Show("����� ������� ������ ���� ��� �������.");

                }
                else
                {
                    MessageBox.Show("�������� ��� ������� � ����.");
                }

            }
            catch
            {
                MessageBox.Show("��������� ���� �����.");
                dataGridView1.ClearSelection();
            }

        }
        int counter = 2;

        //////////////////////////////////////////////INDEXES_COLOR////////////////////////////////////////////////////
        private void materialButton1_Click(object sender, EventArgs e)
        {
            int n = 0;
            dataGridView1.TopLeftHeaderCell.Value = "Matrix";
            DataGridViewColumn column;
            DataGridViewColumn column2;

            /////////////////////////////////////////////////////////////INDEXES///////////////////////////////////////////////////////////////////////////////

            try
            {
                if ((checkBox1.Checked == true && checkBox2.Checked == false) && (checkBox4.Checked == true || checkBox3.Checked == true))
                {

                    dataGridView3.RowCount = 6;
                    dataGridView3.ColumnCount = 6;


                    for (int i = 0; i < 6; i++)
                    {
                        for (int j = 0; j < 6; j++)
                        {
                            column = dataGridView3.Columns[i];
                            column.Width = 30;
                            dataGridView3.Rows[i].Cells[j].Value = n;
                            n++;

                        }
                    }

                 
                    int co=0;

                    for (int i = 0; i < 6; i++)
                    {
                        for (int j = 0; j < 6; j++)
                        {

                            if (Convert.ToInt32(newIndexesForColor[co]) == Convert.ToInt32(dataGridView3.Rows[i].Cells[j].Value))
                            {
                                dataGridView3.Rows[i].Cells[j].Style.BackColor = Color.Purple;
                                i = 0;
                                j = 0;
                                co++;
                            }
                        }
                    }
                }


                else if ((checkBox2.Checked == true && checkBox1.Checked == false) && (checkBox4.Checked == true || checkBox3.Checked == true))
                {

              
                    dataGridView3.RowCount = 7;
                    dataGridView3.ColumnCount = 7;
                    for (int i = 0; i < 7; i++)
                    {
                        for (int j = 0; j < 7; j++)
                        {



                            column2 = dataGridView3.Columns[i];
                            column2.Width = 30;
                            dataGridView3.Rows[i].Cells[j].Value = n;
                            n++;

                        }
                    }
                }
                else if (checkBox1.Checked == true && checkBox2.Checked == true)
                {
                    MessageBox.Show("����� ������� ������ ���� ��� �������.");

                }
                else
                {
                    MessageBox.Show("�������� ��� ������� � ����.");
                }
                counter++;
                int count = 0;

                for (int i = 0; i < 7; i++)
                {
                    for (int j = 0; j < 7; j++)
                    {

                        if (Convert.ToInt32(newIndexesForColor[count]) == Convert.ToInt32(dataGridView3.Rows[i].Cells[j].Value))
                        {
                            dataGridView3.Rows[i].Cells[j].Style.BackColor = Color.Purple;
                            i = 0;
                            j = 0;
                            count++;
                        }
                    }
                }
            }
            catch
            {
                //MessageBox.Show("��������� ���� �����.");
                dataGridView1.ClearSelection();
            }
          
        }
        /////////////////////////////////////////////////////////////ALPHABET-INDEXES///////////////////////////////////////////////////////////////////////////////

        private void materialButton2_Click(object sender, EventArgs e)
        {
            int n = 0;
            dataGridView1.TopLeftHeaderCell.Value = "Matrix";
            DataGridViewColumn column;
            DataGridViewColumn column2;

            /////////////////////////////////////////////////////////////INDEXES///////////////////////////////////////////////////////////////////////////////

            try
            {
                if ((checkBox1.Checked == true && checkBox2.Checked == false) && (checkBox4.Checked == true || checkBox3.Checked == true))
                {
                    dataGridView1.RowCount = 6;
                    dataGridView1.ColumnCount = 6;
                    dataGridView3.RowCount = 6;
                    dataGridView3.ColumnCount = 6;


                    for (int i = 0; i < 6; i++)
                    {
                        for (int j = 0; j < 6; j++)
                        {
                            column = dataGridView1.Columns[i];
                            column.Width = 30;
                            dataGridView1.Rows[i].Cells[j].Value = n;
                            dataGridView3.Rows[i].Cells[j].Value = n;
                            n++;

                        }
                    }
                    for (int i = 0; i < 6; i++)
                    {
                        for (int j = 0; j < 6; j++)
                        {
                            if (i == j) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.BlueViolet;
                            if (i == j - 1) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.AliceBlue;
                            if (i == j - 2) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.CadetBlue;
                            if (i == j - 3) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.CornflowerBlue;
                            if (i == j - 4) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.DarkBlue;
                            if (i == j - 5) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.DarkSlateBlue;
                            if (i == j + 1) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.AliceBlue;
                            if (i == j + 2) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.CadetBlue;
                            if (i == j + 3) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.CornflowerBlue;
                            if (i == j + 4) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.DarkBlue;
                            if (i == j + 5) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.DarkSlateBlue;


                        }
                    }

                    dataGridView2.RowCount = 6;
                    dataGridView2.ColumnCount = 6;
                    int nn = 0;
                    int one = 0;
                    int two = 0;
                    int three = 0;
                    int four = 0;
                    int five = 0;
                    int six = 0;
                    int seven = 0;
                    int eight = 0;
                    int nine = 0;
                    int ten = 0;


                    for (int j = 0; j < 6; j++)
                    {
                        dataGridView2.Rows[0].Cells[j].Style.BackColor = Color.BlueViolet;

                    }

                    for (int j = 0; j < 5; j++)
                    {
                        dataGridView2.Rows[1].Cells[j].Style.BackColor = Color.AliceBlue;

                    }
                    for (int j = 0; j < 6; j++)
                    {
                        dataGridView2.Rows[2].Cells[j].Style.BackColor = Color.CadetBlue;
                        if (j >= 3) dataGridView2.Rows[2].Cells[j].Style.BackColor = Color.CornflowerBlue;

                    }

                    for (int j = 0; j < 6; j++)
                    {
                        dataGridView2.Rows[3].Cells[j].Style.BackColor = Color.DarkBlue;
                        if (j == 2) dataGridView2.Rows[3].Cells[j].Style.BackColor = Color.DarkSlateBlue;
                        if (j > 2) dataGridView2.Rows[3].Cells[j].Style.BackColor = Color.AliceBlue;

                    }
                    dataGridView2.Rows[1].Cells[5].Style.BackColor = Color.CadetBlue;
                    for (int j = 0; j < 6; j++)
                    {
                        dataGridView2.Rows[4].Cells[j].Style.BackColor = Color.AliceBlue;
                        if (j >= 2) dataGridView2.Rows[4].Cells[j].Style.BackColor = Color.CadetBlue;

                    }
                    for (int j = 0; j < 6; j++)
                    {
                        dataGridView2.Rows[5].Cells[j].Style.BackColor = Color.CornflowerBlue;
                        if (j > 2) dataGridView2.Rows[5].Cells[j].Style.BackColor = Color.DarkBlue;
                        if (j == 5) dataGridView2.Rows[5].Cells[j].Style.BackColor = Color.DarkSlateBlue;

                    }



                    for (int i = 0; i < 6; i++)
                    {
                        for (int j = 0; j < 6; j++)
                        {
                            column = dataGridView2.Columns[i];
                            column2 = dataGridView3.Columns[i];
                            column.Width = 30;
                            column2.Width = 30;
                            dataGridView2.Rows[i].Cells[j].Value = nn;
                            nn = nn + 7;
                            one++;
                            two++;
                            three++;
                            four++;
                            five++;
                            six++;
                            seven++;
                            eight++;
                            nine++;
                            ten++;
                            if (one == 6)
                            {
                                nn = 1;
                            }
                            if (two == 11)
                            {
                                nn = 2;
                            }
                            if (three == 15)
                            {
                                nn = 3;
                            }
                            if (four == 18) { nn = 4; }
                            if (five == 20) { nn = 5; }
                            if (six == 21) { nn = 6; }
                            if (seven == 26) { nn = 12; }
                            if (eight == 30) { nn = 18; }
                            if (nine == 33) { nn = 24; }
                            if (eight == 35) { nn = 30; }
                        }
                    }

                }


                else if ((checkBox2.Checked == true && checkBox1.Checked == false) && (checkBox4.Checked == true || checkBox3.Checked == true))
                {

                    dataGridView1.RowCount = 7;
                    dataGridView1.ColumnCount = 7;
                    dataGridView3.RowCount = 7;
                    dataGridView3.ColumnCount = 7;
                    for (int i = 0; i < 7; i++)
                    {
                        for (int j = 0; j < 7; j++)
                        {



                            column = dataGridView1.Columns[i];
                            column2 = dataGridView3.Columns[i];
                            column.Width = 30;
                            column2.Width = 30;
                            dataGridView1.Rows[i].Cells[j].Value = n;
                            dataGridView3.Rows[i].Cells[j].Value = n;
                            n++;

                        }
                    }
                    for (int i = 0; i < 7; i++)
                    {
                        for (int j = 0; j < 7; j++)
                        {
                            if (i == j) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.BlueViolet;
                            if (i == j - 1) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.AliceBlue;
                            if (i == j - 2) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.CadetBlue;
                            if (i == j - 3) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.CornflowerBlue;
                            if (i == j - 4) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.DarkBlue;
                            if (i == j - 5) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.DarkSlateBlue;
                            if (i == j - 6) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.DeepSkyBlue;
                            if (i == j + 1) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.AliceBlue;
                            if (i == j + 2) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.CadetBlue;
                            if (i == j + 3) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.CornflowerBlue;
                            if (i == j + 4) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.DarkBlue;
                            if (i == j + 5) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.DarkSlateBlue;
                            if (i == j + 6) dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.DeepSkyBlue;


                        }
                    }
                    dataGridView2.RowCount = 7;
                    dataGridView2.ColumnCount = 7;
                    int nn = 0;
                    int one = 0;
                    int two = 0;
                    int three = 0;
                    int four = 0;
                    int five = 0;
                    int six = 0;
                    int seven = 0;
                    int eight = 0;
                    int nine = 0;
                    int ten = 0;
                    int eleven = 0;
                    for (int j = 0; j < 7; j++)
                    {
                        dataGridView2.Rows[0].Cells[j].Style.BackColor = Color.BlueViolet;

                    }

                    for (int j = 0; j < 7; j++)
                    {
                        dataGridView2.Rows[1].Cells[j].Style.BackColor = Color.AliceBlue;
                        if (j == 6) dataGridView2.Rows[1].Cells[j].Style.BackColor = Color.CadetBlue;


                    }

                    for (int j = 0; j < 7; j++)
                    {
                        dataGridView2.Rows[2].Cells[j].Style.BackColor = Color.CadetBlue;
                        if (j >= 4) dataGridView2.Rows[2].Cells[j].Style.BackColor = Color.CornflowerBlue;

                    }
                    dataGridView2.Rows[3].Cells[0].Style.BackColor = Color.CornflowerBlue;

                    for (int j = 1; j < 7; j++)
                    {

                        dataGridView2.Rows[3].Cells[j].Style.BackColor = Color.DarkBlue;
                        if (j >= 4) dataGridView2.Rows[3].Cells[j].Style.BackColor = Color.DarkSlateBlue;
                        if (j == 6) dataGridView2.Rows[3].Cells[j].Style.BackColor = Color.DeepSkyBlue;

                    }

                    for (int j = 0; j < 7; j++)
                    {
                        dataGridView2.Rows[4].Cells[j].Style.BackColor = Color.AliceBlue;
                        if (j == 6) dataGridView2.Rows[4].Cells[j].Style.BackColor = Color.CadetBlue;


                    }

                    for (int j = 0; j < 7; j++)
                    {
                        dataGridView2.Rows[5].Cells[j].Style.BackColor = Color.CadetBlue;
                        if (j >= 4) dataGridView2.Rows[5].Cells[j].Style.BackColor = Color.CornflowerBlue;

                    }
                    dataGridView2.Rows[6].Cells[0].Style.BackColor = Color.CornflowerBlue;

                    for (int j = 1; j < 7; j++)
                    {

                        dataGridView2.Rows[6].Cells[j].Style.BackColor = Color.DarkBlue;
                        if (j >= 4) dataGridView2.Rows[6].Cells[j].Style.BackColor = Color.DarkSlateBlue;
                        if (j == 6) dataGridView2.Rows[6].Cells[j].Style.BackColor = Color.DeepSkyBlue;

                    }

                    for (int i = 0; i < 7; i++)
                    {
                        for (int j = 0; j < 7; j++)
                        {
                            column = dataGridView2.Columns[i];
                            column.Width = 30;


                            dataGridView2.Rows[i].Cells[j].Value = nn;


                            nn = nn + 8;
                            one++;
                            two++;
                            three++;
                            four++;
                            five++;
                            six++;
                            seven++;
                            eight++;
                            nine++;
                            ten++;
                            eleven++;
                            if (one == 7) { nn = 1; }
                            if (two == 13) { nn = 2; }
                            if (three == 18) { nn = 3; }
                            if (four == 22) { nn = 4; }
                            if (five == 25) { nn = 5; }
                            if (six == 27) { nn = 6; }
                            if (seven == 28) { nn = 7; }
                            if (eight == 34) { nn = 14; }
                            if (nine == 39) { nn = 21; }
                            if (eight == 43) { nn = 28; }
                            if (ten == 46) { nn = 35; }
                            if (eleven == 48) { nn = 42; }
                        }
                    }
                }
                else if (checkBox1.Checked == true && checkBox2.Checked == true)
                {
                    MessageBox.Show("����� ������� ������ ���� ��� �������.");

                }
                else
                {
                    MessageBox.Show("�������� ��� ������� � ����.");
                }
                counter++;


            }
            catch
            {
                MessageBox.Show("��������� ���� �����.");
                dataGridView1.ClearSelection();
            }
            /////////////////////////////////////////////////////////////ALPHABET///////////////////////////////////////////////////////////////////////////////

            if (counter % 2 == 0)
            {
                char[] ru = AlphabetRus.ToCharArray();
                char[] en = AlphabetEn.ToCharArray();
                n = 0;

                int[] indexDiag = new int[20];
                dataGridView1.TopLeftHeaderCell.Value = "Matrix";

                try
                {
                    if ((checkBox1.Checked == true && checkBox2.Checked == false) && (checkBox4.Checked == true || checkBox3.Checked == true))
                    {
                        dataGridView1.RowCount = 6;
                        dataGridView1.ColumnCount = 6;


                        for (int i = 0; i < 6; i++)
                        {
                            for (int j = 0; j < 6; j++)
                            {
                                if (checkBox3.Checked == true)
                                {
                                    if (n == ru.Length)
                                    {
                                        n = 0;
                                    }
                                    column = dataGridView1.Columns[i];
                                    column.Width = 30;
                                    dataGridView1.Rows[i].Cells[j].Value = ru[n];
                                    dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.White;
                                    diagonalRu6 += ru[n].ToString();
                                    n++;


                                }
                                if (checkBox4.Checked == true)
                                {
                                    if (n == en.Length)
                                    {
                                        n = 0;
                                    }
                                    column = dataGridView1.Columns[i];
                                    column.Width = 30;
                                    dataGridView1.Rows[i].Cells[j].Value = en[n];
                                    dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.White;

                                    diagonalEn6 += en[n].ToString();
                                    n++;
                                }
                            }
                        }

                        dataGridView2.RowCount = 6;
                        dataGridView2.ColumnCount = 6;
                        dataGridView3.RowCount = 6;
                        dataGridView3.ColumnCount = 6;
                        newDiagonalRu6 = diagonalRu6.ToCharArray();
                        newDiagonalEn6 = diagonalEn6.ToCharArray();
                        int nn = 0;
                        int one = 0;
                        int two = 0;
                        int three = 0;
                        int four = 0;
                        int five = 0;
                        int six = 0;
                        int seven = 0;
                        int eight = 0;
                        int nine = 0;
                        int ten = 0;

                        for (int i = 0; i < 6; i++)
                        {
                            for (int j = 0; j < 6; j++)
                            {
                                column = dataGridView2.Columns[i];
                                column.Width = 30;
                                if (checkBox3.Checked == true)
                                {
                                    dataGridView2.Rows[i].Cells[j].Value = newDiagonalRu6[nn];
                                    dataGridView3.Rows[i].Cells[j].Value = newDiagonalRu6[nn];
                                    dataGridView2.Rows[i].Cells[j].Style.BackColor = Color.White;
                                    dataGridView3.Rows[i].Cells[j].Style.BackColor = Color.White;

                                    enddiagonalRu6str += newDiagonalRu6[nn].ToString();
                                }

                                if (checkBox4.Checked == true)
                                {
                                    dataGridView2.Rows[i].Cells[j].Value = newDiagonalEn6[nn];
                                    dataGridView3.Rows[i].Cells[j].Value = newDiagonalEn6[nn];
                                    dataGridView2.Rows[i].Cells[j].Style.BackColor = Color.White;
                                    dataGridView3.Rows[i].Cells[j].Style.BackColor = Color.White;

                                    enddiagonalEn6str += newDiagonalEn6[nn].ToString();

                                }
                                nn = nn + 7;
                                one++;
                                two++;
                                three++;
                                four++;
                                five++;
                                six++;
                                seven++;
                                eight++;
                                nine++;
                                ten++;
                                if (one == 6) { nn = 1; }
                                if (two == 11) { nn = 2; }
                                if (three == 15) { nn = 3; }
                                if (four == 18) { nn = 4; }
                                if (five == 20) { nn = 5; }
                                if (six == 21) { nn = 6; }
                                if (seven == 26) { nn = 12; }
                                if (eight == 30) { nn = 18; }
                                if (nine == 33) { nn = 24; }
                                if (eight == 35) { nn = 30; }
                            }
                        }
                        //for (int l = 0; l < enddiagonalEn6str.Length; l++)
                        //{
                        //    for (int k = enddiagonalEn6str.Length - 1; k >= 0; k--)
                        //    {
                        //        if (enddiagonalEn6str[l] == enddiagonalEn6str[k])
                        //        {
                        //            //MessageBox.Show(l.ToString() + " " + k.ToString());
                        //            if (endDiagonalEn6[l] == endDiagonalEn6[k])
                        //            {
                        //                //MessageBox.Show(l.ToString() + " " + k.ToString());
                        //                indexDiag[n] = l;
                        //                textBox2.Text += indexDiag[n].ToString() + " ";
                        //                n++;
                        //            }
                        //        }
                        //    }

                        //}
                    }

                    else if ((checkBox2.Checked == true && checkBox1.Checked == false) && (checkBox4.Checked == true || checkBox3.Checked == true))
                    {

                        dataGridView1.RowCount = 7;
                        dataGridView1.ColumnCount = 7;
                        for (int i = 0; i < 7; i++)
                        {
                            for (int j = 0; j < 7; j++)
                            {

                                if (checkBox3.Checked == true)
                                {
                                    if (n == ru.Length)
                                    {
                                        n = 0;
                                    }
                                    column = dataGridView1.Columns[i];
                                    column.Width = 30;
                                    dataGridView1.Rows[i].Cells[j].Value = ru[n];
                                    dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.White;

                                    diagonalRu7 += ru[n].ToString();

                                    n++;
                                }
                                if (checkBox4.Checked == true)
                                {
                                    if (n == en.Length)
                                    {
                                        n = 0;
                                    }
                                    column = dataGridView1.Columns[i];
                                    column.Width = 30;
                                    dataGridView1.Rows[i].Cells[j].Value = en[n];
                                    dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.White;

                                    diagonalEn7 += en[n].ToString();
                                    n++;
                                }
                            }
                        }
                        dataGridView2.RowCount = 7;
                        dataGridView2.ColumnCount = 7;
                        dataGridView3.RowCount = 7;
                        dataGridView3.ColumnCount = 7;
                        newDiagonalRu7 = diagonalRu7.ToCharArray();
                        newDiagonalEn7 = diagonalEn7.ToCharArray();
                        int nn = 0;
                        int one = 0;
                        int two = 0;
                        int three = 0;
                        int four = 0;
                        int five = 0;
                        int six = 0;
                        int seven = 0;
                        int eight = 0;
                        int nine = 0;
                        int ten = 0;
                        int eleven = 0;

                        for (int i = 0; i < 7; i++)
                        {
                            for (int j = 0; j < 7; j++)
                            {
                                column = dataGridView2.Columns[i];
                                column.Width = 30;
                                column = dataGridView3.Columns[i];
                                column.Width = 30;
                                if (checkBox3.Checked == true)
                                {
                                    dataGridView2.Rows[i].Cells[j].Value = newDiagonalRu7[nn];
                                    dataGridView3.Rows[i].Cells[j].Value = newDiagonalRu7[nn];
                                    dataGridView2.Rows[i].Cells[j].Style.BackColor = Color.White;
                                    dataGridView3.Rows[i].Cells[j].Style.BackColor = Color.White;

                                    enddiagonalRu7str += newDiagonalRu7[nn].ToString();

                                }

                                if (checkBox4.Checked == true)
                                {
                                    dataGridView2.Rows[i].Cells[j].Value = newDiagonalEn7[nn];
                                    dataGridView3.Rows[i].Cells[j].Value = newDiagonalEn7[nn];
                                    dataGridView2.Rows[i].Cells[j].Style.BackColor = Color.White;
                                    dataGridView3.Rows[i].Cells[j].Style.BackColor = Color.White;

                                    enddiagonalEn7str += newDiagonalEn7[nn].ToString();

                                }
                                nn = nn + 8;
                                one++;
                                two++;
                                three++;
                                four++;
                                five++;
                                six++;
                                seven++;
                                eight++;
                                nine++;
                                ten++;
                                eleven++;
                                if (one == 7) { nn = 1; }
                                if (two == 13) { nn = 2; }
                                if (three == 18) { nn = 3; }
                                if (four == 22) { nn = 4; }
                                if (five == 25) { nn = 5; }
                                if (six == 27) { nn = 6; }
                                if (seven == 28) { nn = 7; }
                                if (eight == 34) { nn = 14; }
                                if (nine == 39) { nn = 21; }
                                if (eight == 43) { nn = 28; }
                                if (ten == 46) { nn = 35; }
                                if (eleven == 48) { nn = 42; }
                            }
                        }
                    }
                    else if (checkBox1.Checked == true && checkBox2.Checked == true)
                    {
                        MessageBox.Show("����� ������� ������ ���� ��� �������.");

                    }
                    else
                    {
                        MessageBox.Show("�������� ��� ������� � ����.");
                    }

                }
                catch
                {
                    MessageBox.Show("��������� ���� �����.");
                    dataGridView1.ClearSelection();
                }
            }

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }





}